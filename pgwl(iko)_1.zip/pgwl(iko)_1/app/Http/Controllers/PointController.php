<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\points;

class pointController extends Controller
{
    public function __construct()
    {
        $this->point = new points();
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $points = $this->point->points();

        foreach ($points as $p) {
            $feature[] = [
                'type' => 'Feature',
                'geometry' => json_decode($p->geom),
                'properties' => [
                    'id' => $p->id,
                    'name' => $p->name,
                    'description' => $p->description,
                    'address' => $p->address,
                    'image' => $p->image,
                    'created_at' => $p->created_at,
                    'updated_at' => $p->updated_at
                ]
                ];
        }

        return response()->json([
            'type' => 'FeatureCollection',
            'features' => $feature,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        //Validate data
        $request->validate([
            'name' => 'required',
            'geom' => 'required',
            'image' => 'mimes:png,jpg,jpeg,gif,tiff|max:10000' //10mb
        ],
        [
            'name.required' => 'Nama lokasi harus diisi',
            'geom.required' => 'Titik lokasi harus diisi',
            'image.mimes' => 'Foto harus memiliki format : png,jpg,jpeg,gif,tiff',
            'image.max' => 'Foto tidak boleh melebihi 10 mb'
        ]);

        //create folder images
        if (!is_dir('storage/images')) {
            mkdir('storage/images', 0777);
        };

        // upload image
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '_point.' . $image->getClientOriginalExtension();
            $image->move('storage/images', $filename);

        }
        else{
            $filename=null;
        }
        $data = [
            'name' => $request->name,
            'description' => $request->description,
            'address'=>$request->address,
            'geom' => $request->geom,
            'image' => $filename
        ];

        // Create point
    if(!$this->point->create($data)){
        return redirect()->back()->with('Error', 'Gagal membuat titik lokasi');
    }

        //Redirect to map
        return redirect()->back()->with('Sukses', 'Titik lokasi berhasil dibuat');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $point = $this->point->point($id);

        foreach ($point as $p) {
            $feature[] = [
                'type' => 'Feature',
                'geometry' => json_decode($p->geom),
                'properties' => [
                    'id' => $p->id,
                    'name' => $p->name,
                    'description' => $p->description,
                    'address' => $p->address,
                    'image' => $p->image,
                    'created_at' => $p->created_at,
                    'updated_at' => $p->updated_at
                ]
                ];
        }

        return response()->json([
            'type' => 'FeatureCollection',
            'features' => $feature,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $point = $this->point->find($id);

        $data = [
            'title' => 'Edit point',
            'point' => $point,
            'id' => $id,
        ];

        return view('edit-point', $data);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //Validate data
        $request->validate([
            'name' => 'required',
            'geom' => 'required',
            'image' => 'mimes:png,jpg,jpeg,gif,tiff|max:10000' //10mb
        ],
        [
            'name.required' => 'Nama lokasi harus diisi',
            'geom.required' => 'Titik lokasi harus diisi',
            'image.mimes' => 'Foto harus memiliki format : png,jpg,jpeg,gif,tiff',
            'image.max' => 'Foto tidak boleh melebihi 10 mb'
        ]);

        //create folder images
        if (!is_dir('storage/images')) {
            mkdir('storage/images', 0777);
        };

        // upload image
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '_point.' . $image->getClientOriginalExtension();
            $image->move('storage/images', $filename);

        //delete image
        $image_old = !$this->point->find($id)->image;
        if($image_old!= null){
            unlink('storage/images/'.$image_old);
        }
     }

        else{
            $filename=$request->image_old;
        }
        $data = [
            'name' => $request->name,
            'description' => $request->description,
            'address' => $request->address,
            'geom' => $request->geom,
            'image' => $filename
        ];

        // Update point
    if(!$this->point->find($id)->update($data)){
        return redirect()->back()->with('Error', 'Gagal menyimpan data');
    }

        //Redirect to map
        return redirect()->back()->with('Sukses', 'Data berhasil tersimpan');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //get point
        $image = $this->point->find($id)->image;

        //delete image

        if($image!= null){
            unlink('storage/images/'.$image);
        }
        //delete point
        if(!$this->point->destroy($id)){
            return redirect()->back()->with('Error', 'Data gagal dihapus');
        }
        //redirect to map
        return redirect()->back()->with('Sukses', 'Data berhasil dihapus');
    }
    public function table()
    {
        $points = $this->point->points();

        $data = [
            'title' => 'Table Point',
            'points' => $points
        ];

        return view('table-point', $data);
    }
}
