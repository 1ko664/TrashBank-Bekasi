<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            <h3>Data Mahasiswa</h3>
        </div>
        <div class="card body">
            <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Hobi</th>
                </tr>
            </thead>


            <tbody>
                <tr>
                    <td>1</td>
                    <td>Jaka</td>
                    <td>Menulis</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Joko</td>
                    <td>Debat</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Juki</td>
                    <td>Mancing</td>
                </tr>
            </tbody>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\pgwl\resources\views/table.blade.php ENDPATH**/ ?>