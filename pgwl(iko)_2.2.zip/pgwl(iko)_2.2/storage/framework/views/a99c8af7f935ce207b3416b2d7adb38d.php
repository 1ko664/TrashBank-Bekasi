<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-2xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Card 1: Total Lokasi Bank Sampah -->
                    <div class="p-6 bg-blue-100 dark:bg-blue-700 rounded-lg shadow-md flex items-center">
                        <div class="text-blue-600 dark:text-blue-200">
                            <i class="fa-solid fa-map-marker-alt fa-3x"></i>
                        </div>

                        <div class="ml-4">
                            <h4 class="text-xl font-semibold">Total Lokasi Bank Sampah Terinput</h4>
                            <p class="text-2xl"><?php echo e($Total_points); ?></p>
                        </div>
                    </div>

                    <!-- Card 2: Add your custom script card -->
                    <div class="p-6 bg-green-100 dark:bg-green-700 rounded-lg shadow-md flex items-center">
                        <div class="text-green-600 dark:text-green-200">
                            <i class="fa-solid fa-code fa-3x"></i>
                        </div>

                        <div class="ml-4">
                            <h4 class="text-xl font-semibold">Kabupaten & Kota Bekasi Juara Penghasil Sampah!</h4>
                            <p class="text-lg">Pelajari dan Jelajahi Lokasi Pengolahan Sampah Pada Peta untuk Menjadi Agen Perubahan</p>
                        </br>
                        <p class="text-lg">Upload Data Lokasi yang Anda Ketahui untuk Memperkaya Informasi Laman Ini!</p>
                            <!-- Replace with your actual script content or embed scripts as needed -->
                        </div>
                    </div>

                    <!-- Add more cards here if needed -->
                </br>
                </div>
                <hr class="my-6 border-gray-300 dark:border-gray-600">
                <div class="text-gray-900 dark:text-gray-100">
                    <p>Anda login sebagai <b><?php echo e(Auth::user()->name); ?></b> dengan email <i><?php echo e(Auth::user()->email); ?></i></p>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Praktikum\4th\PGWEBL\pgwl(iko)\pgwl\resources\views/dashboard.blade.php ENDPATH**/ ?>